<!DOCTYPE html>
<html>
    <head>
        <title>Zoho Portal</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="/zoho/css/uikit.min.css" />
        <script src="/zoho/js/uikit.min.js"></script>
        <script src="/zoho/js/uikit-icons.min.js"></script>
    </head>
    <body>


    <div class="uk-container">
        <nav class="uk-navbar-container" uk-navbar>
            
            <div class="uk-navbar-left">

                <ul class="uk-navbar-nav">
                    <li <li> <li ><img src="/zoho/gmi.png" alt="GMI"class="center"width="400" height="100"></li></li>
<a class="uk-button uk-button-danger"href="<?=base_url().'members';?>">Back To List</a>

                    <!--<li><a href="#"><?php echo $title; ?></a></li>-->

                </ul>

            </div>

            <div class="uk-navbar-right">

                <ul class="uk-navbar-nav">
                    
<li><a href="#" style="cursor: none;">Welcome User</a></li>
                    <li><a href="<?=base_url().'login/logout';?>">Logout</a></li>
                </ul>
            </div>
          
        </nav> 

<div class="uk-section uk-section-primary" style="
    background: #fff;
" >

<h4 id="text" class="uk-h5 tm-heading-fragment" style="color: #000 !important;"><b>Category Has been Added Succesfully</b><br/>

<hr>

 

    <div class="uk-child-width-1-2 @m uk-grid-small uk-grid-match" uk-grid>
    
   

    </div>

         
                    

