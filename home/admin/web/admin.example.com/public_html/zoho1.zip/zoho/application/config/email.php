<?php
 
$config['protocol'] = 'smtp';
$config['smtp_host'] = 'ssl://in.mailjet.com';
$config['smtp_port'] = '465';
$config['smtp_user'] = '22a7cf9df14083c94b1cc4ef5930aba8';
$config['smtp_pass'] = '94181c4b6d1e5eefea87c6239f4fa5ef';
$config['charset'] = 'utf-8';
$config['mailtype'] = 'html';
$config['newline'] = "\r\n";
 
?>