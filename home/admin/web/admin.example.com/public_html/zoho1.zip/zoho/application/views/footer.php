     <nav class="uk-navbar-container" uk-navbar>
            
           <p style="color: #000; margin: 2rem;">Global Market Insights © 2019 All Rights Reserved</p>
          
        </nav> 
    </div>


    </body>
</html>