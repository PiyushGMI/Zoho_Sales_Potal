<!DOCTYPE html>
<html>
    <head>
        <title>Zoho Portal</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="css/uikit.min.css" />
        <script src="js/uikit.min.js"></script>
        <script src="js/uikit-icons.min.js"></script>
    </head>
<style>
img {
  display: block;
  margin-left: auto;
  margin-right: auto;
}
</style>

    <body>


    <div class="uk-container">
        <nav class="uk-navbar-container" uk-navbar>
            
            <div class="uk-navbar-left">

                

            </div>

            <div class="uk-navbar-right">

                <ul class="uk-navbar-nav">
                    <li class="uk-active"><a href="#"></a></li>
                    <li>
                        <a href="#"></a>
                        <div class="uk-navbar-dropdown">
                           
                        </div>
                    </li>
                    <li><a href="#"></a></li>
                </ul>
            </div>
          
        </nav> 
